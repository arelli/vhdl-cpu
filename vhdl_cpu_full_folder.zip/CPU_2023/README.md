# vhdl-cpu
This is a simple MIPS-like CPU simulated on VHDL. It includes a complete Arithmetic Logic Unit(ALU), a Register File(RF), an Instruction Fetch(IF) stage, Memory etc. 
It is developed for a class at my university. It has no real life use except teaching the basics of simple CPU. It is made using Xilinx ISE 14.7(on VM or Win10), and not Vivado.

