/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/ise/Project_2023/CPU_2023/ALU.vhd";
extern char *IEEE_P_0774719531;
extern char *IEEE_P_1242562249;
extern char *IEEE_P_2592010699;

unsigned char ieee_p_0774719531_sub_1306448836232530671_2162500114(char *, char *, char *, char *, char *);
char *ieee_p_0774719531_sub_1496620905533649268_2162500114(char *, char *, char *, char *, char *, char *);
char *ieee_p_0774719531_sub_1496620905533721142_2162500114(char *, char *, char *, char *, char *, char *);
char *ieee_p_1242562249_sub_17249857350030274602_1035706684(char *, char *, char *, char *, int );
char *ieee_p_1242562249_sub_3525738511873258197_1035706684(char *, char *, char *, char *, char *, char *);
char *ieee_p_1242562249_sub_443432982110449621_1035706684(char *, char *, char *, char *, char *, char *);
char *ieee_p_1242562249_sub_443655408936719335_1035706684(char *, char *, char *, char *, char *, char *);
char *ieee_p_1242562249_sub_5461289951233117757_1035706684(char *, char *, char *, char *, int );
char *ieee_p_1242562249_sub_617102632935111766_1035706684(char *, char *, char *, char *, int );
char *ieee_p_1242562249_sub_617102632935327388_1035706684(char *, char *, char *, char *, int );
char *ieee_p_1242562249_sub_8645934262925994370_1035706684(char *, char *, char *, char *, int );
char *ieee_p_2592010699_sub_207919886985903570_503743352(char *, char *, char *, char *);


static void work_a_0832606739_3212880686_p_0(char *t0)
{
    char t32[16];
    char *t1;
    char *t2;
    char *t3;
    int t4;
    char *t5;
    char *t6;
    int t7;
    char *t8;
    char *t9;
    int t10;
    char *t11;
    char *t12;
    int t13;
    char *t14;
    int t16;
    char *t17;
    int t19;
    char *t20;
    int t22;
    char *t23;
    int t25;
    char *t26;
    int t28;
    char *t29;
    int t31;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    unsigned int t39;
    unsigned int t40;
    unsigned char t41;
    char *t42;
    char *t43;
    char *t44;
    char *t45;
    char *t46;

LAB0:    xsi_set_current_line(48, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 8712);
    t4 = xsi_mem_cmp(t1, t2, 4U);
    if (t4 == 1)
        goto LAB3;

LAB14:    t5 = (t0 + 8716);
    t7 = xsi_mem_cmp(t5, t2, 4U);
    if (t7 == 1)
        goto LAB4;

LAB15:    t8 = (t0 + 8720);
    t10 = xsi_mem_cmp(t8, t2, 4U);
    if (t10 == 1)
        goto LAB5;

LAB16:    t11 = (t0 + 8724);
    t13 = xsi_mem_cmp(t11, t2, 4U);
    if (t13 == 1)
        goto LAB6;

LAB17:    t14 = (t0 + 8728);
    t16 = xsi_mem_cmp(t14, t2, 4U);
    if (t16 == 1)
        goto LAB7;

LAB18:    t17 = (t0 + 8732);
    t19 = xsi_mem_cmp(t17, t2, 4U);
    if (t19 == 1)
        goto LAB8;

LAB19:    t20 = (t0 + 8736);
    t22 = xsi_mem_cmp(t20, t2, 4U);
    if (t22 == 1)
        goto LAB9;

LAB20:    t23 = (t0 + 8740);
    t25 = xsi_mem_cmp(t23, t2, 4U);
    if (t25 == 1)
        goto LAB10;

LAB21:    t26 = (t0 + 8744);
    t28 = xsi_mem_cmp(t26, t2, 4U);
    if (t28 == 1)
        goto LAB11;

LAB22:    t29 = (t0 + 8748);
    t31 = xsi_mem_cmp(t29, t2, 4U);
    if (t31 == 1)
        goto LAB12;

LAB23:
LAB13:    xsi_set_current_line(75, ng0);
    t1 = (t0 + 8752);
    t3 = (t0 + 5664);
    t5 = (t3 + 56U);
    t6 = *((char **)t5);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t1, 32U);
    xsi_driver_first_trans_fast(t3);

LAB2:    t1 = (t0 + 5504);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(50, ng0);
    t33 = (t0 + 1032U);
    t34 = *((char **)t33);
    t33 = (t0 + 8472U);
    t35 = (t0 + 1192U);
    t36 = *((char **)t35);
    t35 = (t0 + 8488U);
    t37 = ieee_p_0774719531_sub_1496620905533649268_2162500114(IEEE_P_0774719531, t32, t34, t33, t36, t35);
    t38 = (t32 + 12U);
    t39 = *((unsigned int *)t38);
    t40 = (1U * t39);
    t41 = (32U != t40);
    if (t41 == 1)
        goto LAB25;

LAB26:    t42 = (t0 + 5664);
    t43 = (t42 + 56U);
    t44 = *((char **)t43);
    t45 = (t44 + 56U);
    t46 = *((char **)t45);
    memcpy(t46, t37, 32U);
    xsi_driver_first_trans_fast(t42);
    goto LAB2;

LAB4:    xsi_set_current_line(52, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 8472U);
    t3 = (t0 + 1192U);
    t5 = *((char **)t3);
    t3 = (t0 + 8488U);
    t6 = ieee_p_1242562249_sub_3525738511873258197_1035706684(IEEE_P_1242562249, t32, t2, t1, t5, t3);
    t8 = (t0 + 5664);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t6, 32U);
    xsi_driver_first_trans_fast(t8);
    goto LAB2;

LAB5:    xsi_set_current_line(54, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 8472U);
    t3 = (t0 + 1192U);
    t5 = *((char **)t3);
    t3 = (t0 + 8488U);
    t6 = ieee_p_1242562249_sub_443655408936719335_1035706684(IEEE_P_1242562249, t32, t2, t1, t5, t3);
    t8 = (t0 + 5664);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t6, 32U);
    xsi_driver_first_trans_fast(t8);
    goto LAB2;

LAB6:    xsi_set_current_line(56, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 8472U);
    t3 = (t0 + 1192U);
    t5 = *((char **)t3);
    t3 = (t0 + 8488U);
    t6 = ieee_p_1242562249_sub_443432982110449621_1035706684(IEEE_P_1242562249, t32, t2, t1, t5, t3);
    t8 = (t0 + 5664);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    t12 = (t11 + 56U);
    t14 = *((char **)t12);
    memcpy(t14, t6, 32U);
    xsi_driver_first_trans_fast(t8);
    goto LAB2;

LAB7:    xsi_set_current_line(58, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 8472U);
    t3 = ieee_p_2592010699_sub_207919886985903570_503743352(IEEE_P_2592010699, t32, t2, t1);
    t5 = (t32 + 12U);
    t39 = *((unsigned int *)t5);
    t40 = (1U * t39);
    t41 = (32U != t40);
    if (t41 == 1)
        goto LAB27;

LAB28:    t6 = (t0 + 5664);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    t11 = (t9 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t3, 32U);
    xsi_driver_first_trans_fast(t6);
    goto LAB2;

LAB8:    xsi_set_current_line(61, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 8472U);
    t3 = ieee_p_1242562249_sub_5461289951233117757_1035706684(IEEE_P_1242562249, t32, t2, t1, 1);
    t5 = (t0 + 5664);
    t6 = (t5 + 56U);
    t8 = *((char **)t6);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    memcpy(t11, t3, 32U);
    xsi_driver_first_trans_fast(t5);
    goto LAB2;

LAB9:    xsi_set_current_line(64, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 8472U);
    t3 = ieee_p_1242562249_sub_8645934262925994370_1035706684(IEEE_P_1242562249, t32, t2, t1, 1);
    t5 = (t0 + 5664);
    t6 = (t5 + 56U);
    t8 = *((char **)t6);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    memcpy(t11, t3, 32U);
    xsi_driver_first_trans_fast(t5);
    goto LAB2;

LAB10:    xsi_set_current_line(67, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 8472U);
    t3 = ieee_p_1242562249_sub_17249857350030274602_1035706684(IEEE_P_1242562249, t32, t2, t1, 1);
    t5 = (t0 + 5664);
    t6 = (t5 + 56U);
    t8 = *((char **)t6);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    memcpy(t11, t3, 32U);
    xsi_driver_first_trans_fast(t5);
    goto LAB2;

LAB11:    xsi_set_current_line(70, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 8472U);
    t3 = ieee_p_1242562249_sub_617102632935111766_1035706684(IEEE_P_1242562249, t32, t2, t1, 1);
    t5 = (t0 + 5664);
    t6 = (t5 + 56U);
    t8 = *((char **)t6);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    memcpy(t11, t3, 32U);
    xsi_driver_first_trans_fast(t5);
    goto LAB2;

LAB12:    xsi_set_current_line(73, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t1 = (t0 + 8472U);
    t3 = ieee_p_1242562249_sub_617102632935327388_1035706684(IEEE_P_1242562249, t32, t2, t1, 1);
    t5 = (t0 + 5664);
    t6 = (t5 + 56U);
    t8 = *((char **)t6);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    memcpy(t11, t3, 32U);
    xsi_driver_first_trans_fast(t5);
    goto LAB2;

LAB24:;
LAB25:    xsi_size_not_matching(32U, t40, 0);
    goto LAB26;

LAB27:    xsi_size_not_matching(32U, t40, 0);
    goto LAB28;

}

static void work_a_0832606739_3212880686_p_1(char *t0)
{
    char t5[16];
    char t47[16];
    char t48[16];
    char t49[16];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t6;
    char *t7;
    int t8;
    unsigned int t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    unsigned char t15;
    unsigned int t16;
    unsigned int t17;
    unsigned char t18;
    int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned char t23;
    unsigned char t24;
    int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned char t29;
    int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned char t34;
    unsigned char t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    int t40;
    unsigned int t41;
    unsigned char t42;
    char *t43;
    char *t44;
    char *t45;
    char *t46;
    char *t50;
    char *t51;
    char *t52;
    char *t53;
    char *t54;
    char *t55;

LAB0:    xsi_set_current_line(84, ng0);
    t1 = (t0 + 2152U);
    t2 = *((char **)t1);
    t1 = (t0 + 8536U);
    t3 = (t0 + 8784);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 31;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (31 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t10 = ieee_p_0774719531_sub_1306448836232530671_2162500114(IEEE_P_0774719531, t2, t1, t3, t5);
    if (t10 != 0)
        goto LAB2;

LAB4:    xsi_set_current_line(87, ng0);
    t1 = (t0 + 5728);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);

LAB3:    xsi_set_current_line(92, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t8 = (31 - 31);
    t9 = (t8 * -1);
    t16 = (1U * t9);
    t17 = (0 + t16);
    t1 = (t2 + t17);
    t18 = *((unsigned char *)t1);
    t3 = (t0 + 1192U);
    t4 = *((char **)t3);
    t19 = (31 - 31);
    t20 = (t19 * -1);
    t21 = (1U * t20);
    t22 = (0 + t21);
    t3 = (t4 + t22);
    t23 = *((unsigned char *)t3);
    t24 = (t18 == t23);
    if (t24 == 1)
        goto LAB11;

LAB12:    t15 = (unsigned char)0;

LAB13:    if (t15 == 1)
        goto LAB8;

LAB9:    t10 = (unsigned char)0;

LAB10:    if (t10 != 0)
        goto LAB5;

LAB7:    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t8 = (31 - 31);
    t9 = (t8 * -1);
    t16 = (1U * t9);
    t17 = (0 + t16);
    t1 = (t2 + t17);
    t18 = *((unsigned char *)t1);
    t3 = (t0 + 1192U);
    t4 = *((char **)t3);
    t19 = (31 - 31);
    t20 = (t19 * -1);
    t21 = (1U * t20);
    t22 = (0 + t21);
    t3 = (t4 + t22);
    t23 = *((unsigned char *)t3);
    t24 = (t18 != t23);
    if (t24 == 1)
        goto LAB19;

LAB20:    t15 = (unsigned char)0;

LAB21:    if (t15 == 1)
        goto LAB16;

LAB17:    t10 = (unsigned char)0;

LAB18:    if (t10 != 0)
        goto LAB14;

LAB15:    xsi_set_current_line(98, ng0);
    t1 = (t0 + 5792);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);

LAB6:    xsi_set_current_line(102, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 8504U);
    t3 = (t0 + 8824);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 3;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (3 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t10 = ieee_p_0774719531_sub_1306448836232530671_2162500114(IEEE_P_0774719531, t2, t1, t3, t5);
    if (t10 != 0)
        goto LAB22;

LAB24:    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 8504U);
    t3 = (t0 + 8828);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 3;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (3 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t10 = ieee_p_0774719531_sub_1306448836232530671_2162500114(IEEE_P_0774719531, t2, t1, t3, t5);
    if (t10 != 0)
        goto LAB27;

LAB28:    xsi_set_current_line(109, ng0);
    t1 = (t0 + 5920);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);

LAB23:    t1 = (t0 + 5520);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(85, ng0);
    t7 = (t0 + 5728);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    *((unsigned char *)t14) = (unsigned char)3;
    xsi_driver_first_trans_fast(t7);
    goto LAB3;

LAB5:    xsi_set_current_line(93, ng0);
    t39 = (t0 + 5792);
    t43 = (t39 + 56U);
    t44 = *((char **)t43);
    t45 = (t44 + 56U);
    t46 = *((char **)t45);
    *((unsigned char *)t46) = (unsigned char)3;
    xsi_driver_first_trans_fast(t39);
    goto LAB6;

LAB8:    t13 = (t0 + 1352U);
    t14 = *((char **)t13);
    t13 = (t0 + 8504U);
    t36 = (t0 + 8816);
    t38 = (t5 + 0U);
    t39 = (t38 + 0U);
    *((int *)t39) = 0;
    t39 = (t38 + 4U);
    *((int *)t39) = 3;
    t39 = (t38 + 8U);
    *((int *)t39) = 1;
    t40 = (3 - 0);
    t41 = (t40 * 1);
    t41 = (t41 + 1);
    t39 = (t38 + 12U);
    *((unsigned int *)t39) = t41;
    t42 = ieee_p_0774719531_sub_1306448836232530671_2162500114(IEEE_P_0774719531, t14, t13, t36, t5);
    t10 = t42;
    goto LAB10;

LAB11:    t6 = (t0 + 1032U);
    t7 = *((char **)t6);
    t25 = (31 - 31);
    t26 = (t25 * -1);
    t27 = (1U * t26);
    t28 = (0 + t27);
    t6 = (t7 + t28);
    t29 = *((unsigned char *)t6);
    t11 = (t0 + 2152U);
    t12 = *((char **)t11);
    t30 = (31 - 31);
    t31 = (t30 * -1);
    t32 = (1U * t31);
    t33 = (0 + t32);
    t11 = (t12 + t33);
    t34 = *((unsigned char *)t11);
    t35 = (t29 != t34);
    t15 = t35;
    goto LAB13;

LAB14:    xsi_set_current_line(96, ng0);
    t39 = (t0 + 5792);
    t43 = (t39 + 56U);
    t44 = *((char **)t43);
    t45 = (t44 + 56U);
    t46 = *((char **)t45);
    *((unsigned char *)t46) = (unsigned char)3;
    xsi_driver_first_trans_fast(t39);
    goto LAB6;

LAB16:    t13 = (t0 + 1352U);
    t14 = *((char **)t13);
    t13 = (t0 + 8504U);
    t36 = (t0 + 8820);
    t38 = (t5 + 0U);
    t39 = (t38 + 0U);
    *((int *)t39) = 0;
    t39 = (t38 + 4U);
    *((int *)t39) = 3;
    t39 = (t38 + 8U);
    *((int *)t39) = 1;
    t40 = (3 - 0);
    t41 = (t40 * 1);
    t41 = (t41 + 1);
    t39 = (t38 + 12U);
    *((unsigned int *)t39) = t41;
    t42 = ieee_p_0774719531_sub_1306448836232530671_2162500114(IEEE_P_0774719531, t14, t13, t36, t5);
    t10 = t42;
    goto LAB18;

LAB19:    t6 = (t0 + 1032U);
    t7 = *((char **)t6);
    t25 = (31 - 31);
    t26 = (t25 * -1);
    t27 = (1U * t26);
    t28 = (0 + t27);
    t6 = (t7 + t28);
    t29 = *((unsigned char *)t6);
    t11 = (t0 + 2152U);
    t12 = *((char **)t11);
    t30 = (31 - 31);
    t31 = (t30 * -1);
    t32 = (1U * t31);
    t33 = (0 + t32);
    t11 = (t12 + t33);
    t34 = *((unsigned char *)t11);
    t35 = (t29 != t34);
    t15 = t35;
    goto LAB21;

LAB22:    xsi_set_current_line(103, ng0);
    t7 = (t0 + 1032U);
    t11 = *((char **)t7);
    t19 = (31 - 31);
    t9 = (t19 * -1);
    t16 = (1U * t9);
    t17 = (0 + t16);
    t7 = (t11 + t17);
    t15 = *((unsigned char *)t7);
    t12 = (t0 + 1032U);
    t13 = *((char **)t12);
    t14 = ((IEEE_P_2592010699) + 4000);
    t36 = (t0 + 8472U);
    t12 = xsi_base_array_concat(t12, t48, t14, (char)99, t15, (char)97, t13, t36, (char)101);
    t37 = (t0 + 1192U);
    t38 = *((char **)t37);
    t25 = (31 - 31);
    t20 = (t25 * -1);
    t21 = (1U * t20);
    t22 = (0 + t21);
    t37 = (t38 + t22);
    t18 = *((unsigned char *)t37);
    t39 = (t0 + 1192U);
    t43 = *((char **)t39);
    t44 = ((IEEE_P_2592010699) + 4000);
    t45 = (t0 + 8488U);
    t39 = xsi_base_array_concat(t39, t49, t44, (char)99, t18, (char)97, t43, t45, (char)101);
    t46 = ieee_p_0774719531_sub_1496620905533721142_2162500114(IEEE_P_0774719531, t47, t12, t48, t39, t49);
    t50 = (t47 + 12U);
    t26 = *((unsigned int *)t50);
    t27 = (1U * t26);
    t23 = (33U != t27);
    if (t23 == 1)
        goto LAB25;

LAB26:    t51 = (t0 + 5856);
    t52 = (t51 + 56U);
    t53 = *((char **)t52);
    t54 = (t53 + 56U);
    t55 = *((char **)t54);
    memcpy(t55, t46, 33U);
    xsi_driver_first_trans_fast(t51);
    xsi_set_current_line(104, ng0);
    t1 = (t0 + 2312U);
    t2 = *((char **)t1);
    t8 = (32 - 32);
    t9 = (t8 * -1);
    t16 = (1U * t9);
    t17 = (0 + t16);
    t1 = (t2 + t17);
    t10 = *((unsigned char *)t1);
    t3 = (t0 + 5920);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    *((unsigned char *)t11) = t10;
    xsi_driver_first_trans_fast(t3);
    goto LAB23;

LAB25:    xsi_size_not_matching(33U, t27, 0);
    goto LAB26;

LAB27:    xsi_set_current_line(106, ng0);
    t7 = (t0 + 1032U);
    t11 = *((char **)t7);
    t19 = (31 - 31);
    t9 = (t19 * -1);
    t16 = (1U * t9);
    t17 = (0 + t16);
    t7 = (t11 + t17);
    t15 = *((unsigned char *)t7);
    t12 = (t0 + 1032U);
    t13 = *((char **)t12);
    t14 = ((IEEE_P_2592010699) + 4000);
    t36 = (t0 + 8472U);
    t12 = xsi_base_array_concat(t12, t48, t14, (char)99, t15, (char)97, t13, t36, (char)101);
    t37 = (t0 + 1192U);
    t38 = *((char **)t37);
    t25 = (31 - 31);
    t20 = (t25 * -1);
    t21 = (1U * t20);
    t22 = (0 + t21);
    t37 = (t38 + t22);
    t18 = *((unsigned char *)t37);
    t39 = (t0 + 1192U);
    t43 = *((char **)t39);
    t44 = ((IEEE_P_2592010699) + 4000);
    t45 = (t0 + 8488U);
    t39 = xsi_base_array_concat(t39, t49, t44, (char)99, t18, (char)97, t43, t45, (char)101);
    t46 = ieee_p_0774719531_sub_1496620905533649268_2162500114(IEEE_P_0774719531, t47, t12, t48, t39, t49);
    t50 = (t47 + 12U);
    t26 = *((unsigned int *)t50);
    t27 = (1U * t26);
    t23 = (33U != t27);
    if (t23 == 1)
        goto LAB29;

LAB30:    t51 = (t0 + 5856);
    t52 = (t51 + 56U);
    t53 = *((char **)t52);
    t54 = (t53 + 56U);
    t55 = *((char **)t54);
    memcpy(t55, t46, 33U);
    xsi_driver_first_trans_fast(t51);
    xsi_set_current_line(107, ng0);
    t1 = (t0 + 2312U);
    t2 = *((char **)t1);
    t8 = (32 - 32);
    t9 = (t8 * -1);
    t16 = (1U * t9);
    t17 = (0 + t16);
    t1 = (t2 + t17);
    t10 = *((unsigned char *)t1);
    t3 = (t0 + 5920);
    t4 = (t3 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t11 = *((char **)t7);
    *((unsigned char *)t11) = t10;
    xsi_driver_first_trans_fast(t3);
    goto LAB23;

LAB29:    xsi_size_not_matching(33U, t27, 0);
    goto LAB30;

}

static void work_a_0832606739_3212880686_p_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(118, ng0);

LAB3:    t1 = (t0 + 2152U);
    t2 = *((char **)t1);
    t1 = (t0 + 5984);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 32U);
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t7 = (t0 + 5536);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0832606739_3212880686_p_3(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(119, ng0);

LAB3:    t1 = (t0 + 2792U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 6048);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 5552);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0832606739_3212880686_p_4(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(120, ng0);

LAB3:    t1 = (t0 + 2632U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 6112);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 5568);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0832606739_3212880686_p_5(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(121, ng0);

LAB3:    t1 = (t0 + 2472U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 6176);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 5584);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}


extern void work_a_0832606739_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0832606739_3212880686_p_0,(void *)work_a_0832606739_3212880686_p_1,(void *)work_a_0832606739_3212880686_p_2,(void *)work_a_0832606739_3212880686_p_3,(void *)work_a_0832606739_3212880686_p_4,(void *)work_a_0832606739_3212880686_p_5};
	xsi_register_didat("work_a_0832606739_3212880686", "isim/CPU_single_cycle_tb_isim_beh.exe.sim/work/a_0832606739_3212880686.didat");
	xsi_register_executes(pe);
}
