/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/ise/Project_2023/CPU_2023/immed_bubble.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_1242562249;

char *ieee_p_1242562249_sub_2423793367844140314_1035706684(char *, char *, char *, char *, int );
char *ieee_p_1242562249_sub_2749763749646623249_1035706684(char *, char *, char *, char *, int );


static void work_a_2833009315_3212880686_p_0(char *t0)
{
    char t9[16];
    char t11[16];
    char t16[16];
    char *t1;
    char *t2;
    unsigned int t3;
    unsigned int t4;
    unsigned int t5;
    char *t6;
    char *t7;
    char *t8;
    char *t10;
    char *t12;
    char *t13;
    int t14;
    unsigned int t15;
    char *t17;
    int t18;
    unsigned char t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    int t24;
    int t25;
    int t26;
    int t28;
    char *t29;
    int t31;
    char *t32;
    int t34;
    char *t35;
    int t37;
    char *t38;
    int t40;
    char *t41;
    int t43;
    char *t44;
    int t46;
    char *t47;
    char *t48;
    unsigned int t49;
    unsigned int t50;
    char *t51;
    char *t52;
    int t53;
    unsigned int t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    char *t59;

LAB0:    xsi_set_current_line(22, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = (31 - 15);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 5010);
    t10 = ((IEEE_P_2592010699) + 4000);
    t12 = (t11 + 0U);
    t13 = (t12 + 0U);
    *((int *)t13) = 15;
    t13 = (t12 + 4U);
    *((int *)t13) = 0;
    t13 = (t12 + 8U);
    *((int *)t13) = -1;
    t14 = (0 - 15);
    t15 = (t14 * -1);
    t15 = (t15 + 1);
    t13 = (t12 + 12U);
    *((unsigned int *)t13) = t15;
    t13 = (t16 + 0U);
    t17 = (t13 + 0U);
    *((int *)t17) = 0;
    t17 = (t13 + 4U);
    *((int *)t17) = 1;
    t17 = (t13 + 8U);
    *((int *)t17) = 1;
    t18 = (1 - 0);
    t15 = (t18 * 1);
    t15 = (t15 + 1);
    t17 = (t13 + 12U);
    *((unsigned int *)t17) = t15;
    t8 = xsi_base_array_concat(t8, t9, t10, (char)97, t1, t11, (char)97, t6, t16, (char)101);
    t15 = (16U + 2U);
    t19 = (18U != t15);
    if (t19 == 1)
        goto LAB2;

LAB3:    t17 = (t0 + 3064);
    t20 = (t17 + 56U);
    t21 = *((char **)t20);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    memcpy(t23, t8, 18U);
    xsi_driver_first_trans_fast(t17);
    xsi_set_current_line(23, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = (31 - 31);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 5012);
    t14 = xsi_mem_cmp(t6, t1, 6U);
    if (t14 == 1)
        goto LAB5;

LAB10:    t8 = (t0 + 5018);
    t18 = xsi_mem_cmp(t8, t1, 6U);
    if (t18 == 1)
        goto LAB5;

LAB11:    t12 = (t0 + 5024);
    t24 = xsi_mem_cmp(t12, t1, 6U);
    if (t24 == 1)
        goto LAB6;

LAB12:    t17 = (t0 + 5030);
    t25 = xsi_mem_cmp(t17, t1, 6U);
    if (t25 == 1)
        goto LAB6;

LAB13:    t21 = (t0 + 5036);
    t26 = xsi_mem_cmp(t21, t1, 6U);
    if (t26 == 1)
        goto LAB6;

LAB14:    t23 = (t0 + 5042);
    t28 = xsi_mem_cmp(t23, t1, 6U);
    if (t28 == 1)
        goto LAB6;

LAB15:    t29 = (t0 + 5048);
    t31 = xsi_mem_cmp(t29, t1, 6U);
    if (t31 == 1)
        goto LAB6;

LAB16:    t32 = (t0 + 5054);
    t34 = xsi_mem_cmp(t32, t1, 6U);
    if (t34 == 1)
        goto LAB6;

LAB17:    t35 = (t0 + 5060);
    t37 = xsi_mem_cmp(t35, t1, 6U);
    if (t37 == 1)
        goto LAB7;

LAB18:    t38 = (t0 + 5066);
    t40 = xsi_mem_cmp(t38, t1, 6U);
    if (t40 == 1)
        goto LAB7;

LAB19:    t41 = (t0 + 5072);
    t43 = xsi_mem_cmp(t41, t1, 6U);
    if (t43 == 1)
        goto LAB7;

LAB20:    t44 = (t0 + 5078);
    t46 = xsi_mem_cmp(t44, t1, 6U);
    if (t46 == 1)
        goto LAB8;

LAB21:
LAB9:    xsi_set_current_line(33, ng0);
    t1 = (t0 + 5100);
    t6 = (t0 + 3128);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t10 = (t8 + 56U);
    t12 = *((char **)t10);
    memcpy(t12, t1, 32U);
    xsi_driver_first_trans_fast(t6);

LAB4:    xsi_set_current_line(35, ng0);
    t1 = (t0 + 1352U);
    t2 = *((char **)t1);
    t1 = (t0 + 3192);
    t6 = (t1 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t10 = *((char **)t8);
    memcpy(t10, t2, 32U);
    xsi_driver_first_trans_fast_port(t1);
    t1 = (t0 + 2984);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_size_not_matching(18U, t15, 0);
    goto LAB3;

LAB5:    xsi_set_current_line(25, ng0);
    t47 = (t0 + 1032U);
    t48 = *((char **)t47);
    t15 = (31 - 15);
    t49 = (t15 * 1U);
    t50 = (0 + t49);
    t47 = (t48 + t50);
    t51 = (t11 + 0U);
    t52 = (t51 + 0U);
    *((int *)t52) = 15;
    t52 = (t51 + 4U);
    *((int *)t52) = 0;
    t52 = (t51 + 8U);
    *((int *)t52) = -1;
    t53 = (0 - 15);
    t54 = (t53 * -1);
    t54 = (t54 + 1);
    t52 = (t51 + 12U);
    *((unsigned int *)t52) = t54;
    t52 = ieee_p_1242562249_sub_2749763749646623249_1035706684(IEEE_P_1242562249, t9, t47, t11, 32);
    t55 = (t0 + 3128);
    t56 = (t55 + 56U);
    t57 = *((char **)t56);
    t58 = (t57 + 56U);
    t59 = *((char **)t58);
    memcpy(t59, t52, 32U);
    xsi_driver_first_trans_fast(t55);
    goto LAB4;

LAB6:    xsi_set_current_line(27, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = (31 - 15);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t11 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 15;
    t7 = (t6 + 4U);
    *((int *)t7) = 0;
    t7 = (t6 + 8U);
    *((int *)t7) = -1;
    t14 = (0 - 15);
    t15 = (t14 * -1);
    t15 = (t15 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t15;
    t7 = ieee_p_1242562249_sub_2423793367844140314_1035706684(IEEE_P_1242562249, t9, t1, t11, 32);
    t8 = (t0 + 3128);
    t10 = (t8 + 56U);
    t12 = *((char **)t10);
    t13 = (t12 + 56U);
    t17 = *((char **)t13);
    memcpy(t17, t7, 32U);
    xsi_driver_first_trans_fast(t8);
    goto LAB4;

LAB7:    xsi_set_current_line(29, ng0);
    t1 = (t0 + 1512U);
    t2 = *((char **)t1);
    t1 = (t0 + 4904U);
    t6 = ieee_p_1242562249_sub_2423793367844140314_1035706684(IEEE_P_1242562249, t9, t2, t1, 32);
    t7 = (t0 + 3128);
    t8 = (t7 + 56U);
    t10 = *((char **)t8);
    t12 = (t10 + 56U);
    t13 = *((char **)t12);
    memcpy(t13, t6, 32U);
    xsi_driver_first_trans_fast(t7);
    goto LAB4;

LAB8:    xsi_set_current_line(31, ng0);
    t1 = (t0 + 1032U);
    t2 = *((char **)t1);
    t3 = (31 - 15);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 5084);
    t10 = ((IEEE_P_2592010699) + 4000);
    t12 = (t11 + 0U);
    t13 = (t12 + 0U);
    *((int *)t13) = 15;
    t13 = (t12 + 4U);
    *((int *)t13) = 0;
    t13 = (t12 + 8U);
    *((int *)t13) = -1;
    t14 = (0 - 15);
    t15 = (t14 * -1);
    t15 = (t15 + 1);
    t13 = (t12 + 12U);
    *((unsigned int *)t13) = t15;
    t13 = (t16 + 0U);
    t17 = (t13 + 0U);
    *((int *)t17) = 0;
    t17 = (t13 + 4U);
    *((int *)t17) = 15;
    t17 = (t13 + 8U);
    *((int *)t17) = 1;
    t18 = (15 - 0);
    t15 = (t18 * 1);
    t15 = (t15 + 1);
    t17 = (t13 + 12U);
    *((unsigned int *)t17) = t15;
    t8 = xsi_base_array_concat(t8, t9, t10, (char)97, t1, t11, (char)97, t6, t16, (char)101);
    t15 = (16U + 16U);
    t19 = (32U != t15);
    if (t19 == 1)
        goto LAB23;

LAB24:    t17 = (t0 + 3128);
    t20 = (t17 + 56U);
    t21 = *((char **)t20);
    t22 = (t21 + 56U);
    t23 = *((char **)t22);
    memcpy(t23, t8, 32U);
    xsi_driver_first_trans_fast(t17);
    goto LAB4;

LAB22:;
LAB23:    xsi_size_not_matching(32U, t15, 0);
    goto LAB24;

}


extern void work_a_2833009315_3212880686_init()
{
	static char *pe[] = {(void *)work_a_2833009315_3212880686_p_0};
	xsi_register_didat("work_a_2833009315_3212880686", "isim/CPU_single_cycle_tb_isim_beh.exe.sim/work/a_2833009315_3212880686.didat");
	xsi_register_executes(pe);
}
